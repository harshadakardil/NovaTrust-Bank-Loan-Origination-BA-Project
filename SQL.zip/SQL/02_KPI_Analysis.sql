SELECT
    COUNT(*) AS total_applications,
    ROUND(AVG(loan_amount), 2) AS average_loan_amount,
    ROUND(AVG(credit_score), 2) AS average_credit_score,
    ROUND(AVG(tat_days), 2) AS average_tat_days
FROM loan_applications;

SELECT
    COUNT(*) AS total_applications,
    SUM(CASE
        WHEN final_decision != 'Abandoned' THEN 1
        ELSE 0
    END) AS decided_applications,
    SUM(CASE
        WHEN final_decision = 'Approved' THEN 1
        ELSE 0
    END) AS approved_applications,
    SUM(CASE
        WHEN application_status = 'Abandoned' THEN 1
        ELSE 0
    END) AS abandoned_applications,
    ROUND(
        SUM(CASE
            WHEN final_decision = 'Approved' THEN 1
            ELSE 0
        END) * 100.0
        / NULLIF(
            SUM(CASE
                WHEN final_decision != 'Abandoned' THEN 1
                ELSE 0
            END), 0
        ), 2
    ) AS approval_rate_pct_of_decided,
    ROUND(
        SUM(CASE
            WHEN application_status = 'Abandoned' THEN 1
            ELSE 0
        END) * 100.0 / COUNT(*), 2
    ) AS abandonment_rate_pct
FROM loan_applications;

SELECT
    customer_segment,
    COUNT(*) AS total_applications,
    SUM(CASE WHEN final_decision != 'Abandoned' THEN 1 ELSE 0 END) AS decided_applications,
    SUM(CASE WHEN final_decision = 'Approved' THEN 1 ELSE 0 END) AS approved_applications,
    ROUND(
        SUM(CASE WHEN final_decision = 'Approved' THEN 1 ELSE 0 END) * 100.0
        / NULLIF(
            SUM(CASE WHEN final_decision != 'Abandoned' THEN 1 ELSE 0 END),
            0
        ),
        2
    ) AS approval_rate_pct_of_decided,
    ROUND(AVG(tat_days), 2) AS average_tat_days
FROM loan_applications
GROUP BY customer_segment
ORDER BY customer_segment;

SELECT
    channel,
    COUNT(*) AS total_applications,
    SUM(CASE WHEN final_decision != 'Abandoned' THEN 1 ELSE 0 END) AS decided_applications,
    SUM(CASE WHEN final_decision = 'Approved' THEN 1 ELSE 0 END) AS approved_applications,
    ROUND(
        SUM(CASE WHEN final_decision = 'Approved' THEN 1 ELSE 0 END) * 100.0
        / NULLIF(
            SUM(CASE WHEN final_decision != 'Abandoned' THEN 1 ELSE 0 END),
            0
        ),
        2
    ) AS approval_rate_pct_of_decided,
    ROUND(AVG(tat_days), 2) AS average_tat_days
FROM loan_applications
GROUP BY channel
ORDER BY channel;