SELECT
    COUNT(*) AS total_applications,
    SUM(CASE WHEN final_decision != 'Abandoned' THEN 1 ELSE 0 END) AS decided_applications,
    SUM(CASE WHEN final_decision = 'Approved' THEN 1 ELSE 0 END) AS approved_applications,
    SUM(CASE WHEN application_status = 'Abandoned' THEN 1 ELSE 0 END) AS abandoned_applications,
    ROUND(
        SUM(CASE WHEN final_decision = 'Approved' THEN 1 ELSE 0 END) * 100.0
        / NULLIF(
            SUM(CASE WHEN final_decision != 'Abandoned' THEN 1 ELSE 0 END),
            0
        ),
        2
    ) AS approval_rate_pct_of_decided,
    ROUND(AVG(loan_amount), 2) AS average_loan_amount,
    ROUND(AVG(credit_score), 2) AS average_credit_score,
    ROUND(AVG(tat_days), 2) AS average_tat_days,
    SUM(CASE WHEN tat_days > 3 THEN 1 ELSE 0 END) AS sla_breaches
FROM loan_applications;



SELECT
    application_status,
    COUNT(*) AS total_applications,
    ROUND(
        COUNT(*) * 100.0 / (SELECT COUNT(*) FROM loan_applications),
        2
    ) AS percentage_of_applications
FROM loan_applications
GROUP BY application_status
ORDER BY total_applications DESC;

SELECT
    application_id,
    customer_segment,
    channel,
    loan_amount,
    tat_days,
    application_status
FROM loan_applications
WHERE tat_days IS NOT NULL
ORDER BY tat_days DESC
LIMIT 10;

SELECT
    COUNT(*) AS records_with_decision_date,
    SUM(
        CASE
            WHEN decision_date IS NOT NULL
             AND ABS(tat_days - DATEDIFF(decision_date, submission_date)) > 0.5
            THEN 1
            ELSE 0
        END
    ) AS tat_mismatch_records
FROM loan_applications
WHERE decision_date IS NOT NULL;

SELECT
    MIN(tat_days) AS minimum_tat,
    MAX(tat_days) AS maximum_tat,
    ROUND(AVG(tat_days), 2) AS average_tat,
    ROUND(AVG(DATEDIFF(decision_date, submission_date)), 2) AS average_calendar_days,
    ROUND(AVG(tat_days - DATEDIFF(decision_date, submission_date)), 2) AS average_tat_difference
FROM loan_applications
WHERE decision_date IS NOT NULL
  AND tat_days IS NOT NULL;
  
WITH officer_stats AS (
    SELECT
        loan_officer,
        COUNT(*) AS total_applications,
        SUM(
            CASE
                WHEN final_decision != 'Abandoned'
                THEN 1
                ELSE 0
            END
        ) AS decided_applications,
        SUM(
            CASE
                WHEN final_decision = 'Approved'
                THEN 1
                ELSE 0
            END
        ) AS approved_applications,
        ROUND(AVG(tat_days), 2) AS average_tat_days
    FROM loan_applications
    GROUP BY loan_officer
)

SELECT
    loan_officer,
    total_applications,
    decided_applications,
    approved_applications,
    ROUND(
        approved_applications * 100.0
        / NULLIF(decided_applications, 0),
        2
    ) AS approval_rate_pct_of_decided,
    average_tat_days,
    RANK() OVER (
        ORDER BY total_applications DESC
    ) AS volume_rank
FROM officer_stats
ORDER BY volume_rank;