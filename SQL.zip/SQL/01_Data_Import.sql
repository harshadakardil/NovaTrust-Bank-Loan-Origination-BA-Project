CREATE DATABASE IF NOT EXISTS novatrust_loans;

USE novatrust_loans;



CREATE TABLE IF NOT EXISTS loan_applications (
    application_id VARCHAR(20) NOT NULL PRIMARY KEY,
    customer_id VARCHAR(20),
    customer_name VARCHAR(100),
    customer_segment VARCHAR(50),
    channel VARCHAR(50),
    region VARCHAR(100),
    loan_amount DECIMAL(12,2),
    tenure_months INT,
    submission_date DATE,
    document_status VARCHAR(50),
    document_resubmission_count INT,
    kyc_aml_status VARCHAR(50),
    credit_score INT,
    credit_assessment_result VARCHAR(50),
    loan_officer VARCHAR(100),
    approver VARCHAR(100),
    final_decision VARCHAR(50),
    decision_date DATE,
    tat_days DECIMAL(6,2),
    disbursement_date DATE,
    application_status VARCHAR(50)
);


DESCRIBE loan_applications;


LOAD DATA LOCAL INFILE 'C:/Users/HP/OneDrive/Desktop/BA/BA Project for Resume/Banking Loan Orientation/loan_applications_win.csv'
INTO TABLE loan_applications
FIELDS TERMINATED BY ','
OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 ROWS
(
    application_id,
    customer_id,
    customer_name,
    customer_segment,
    channel,
    region,
    loan_amount,
    tenure_months,
    submission_date,
    document_status,
    document_resubmission_count,
    kyc_aml_status,
    credit_score,
    credit_assessment_result,
    loan_officer,
    approver,
    final_decision,
    @decision_date,
    @tat_days,
    @disbursement_date,
    application_status
)
SET
    decision_date = NULLIF(@decision_date, ''),
    tat_days = NULLIF(@tat_days, ''),
    disbursement_date = NULLIF(@disbursement_date, '');


SELECT COUNT(*) AS total_rows
FROM loan_applications;

SELECT *
FROM loan_applications
LIMIT 5;