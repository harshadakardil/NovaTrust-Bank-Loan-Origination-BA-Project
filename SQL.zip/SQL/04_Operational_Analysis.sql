SELECT
    loan_officer,
    COUNT(*) AS total_applications,
    SUM(CASE WHEN final_decision != 'Abandoned' THEN 1 ELSE 0 END) AS decided_applications,
    SUM(CASE WHEN final_decision = 'Approved' THEN 1 ELSE 0 END) AS approved_applications,
    ROUND(
        SUM(CASE WHEN final_decision = 'Approved' THEN 1 ELSE 0 END) * 100.0
        / NULLIF(
            SUM(CASE WHEN final_decision != 'Abandoned' THEN 1 ELSE 0 END),
            0
        ),
        2
    ) AS approval_rate_pct_of_decided,
    ROUND(AVG(tat_days), 2) AS average_tat_days
FROM loan_applications
GROUP BY loan_officer
ORDER BY total_applications DESC;

SELECT
    document_status,
    COUNT(*) AS total_applications,
    SUM(CASE WHEN document_resubmission_count > 0 THEN 1 ELSE 0 END) AS applications_with_resubmission,
    ROUND(AVG(document_resubmission_count), 2) AS average_resubmissions
FROM loan_applications
GROUP BY document_status
ORDER BY total_applications DESC;

SELECT
    kyc_aml_status,
    COUNT(*) AS total_applications,
    ROUND(
        COUNT(*) * 100.0 / (SELECT COUNT(*) FROM loan_applications),
        2
    ) AS percentage_of_applications
FROM loan_applications
GROUP BY kyc_aml_status
ORDER BY total_applications DESC;