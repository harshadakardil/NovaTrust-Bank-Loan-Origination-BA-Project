SELECT
    application_id,
    customer_segment,
    channel,
    loan_amount,
    submission_date,
    decision_date,
    tat_days,
    application_status
FROM loan_applications
WHERE tat_days > 7
ORDER BY tat_days DESC;

SELECT
    COUNT(*) AS total_applications,
    SUM(CASE WHEN tat_days > 3 THEN 1 ELSE 0 END) AS sla_breaches,
    ROUND(
        SUM(CASE WHEN tat_days > 3 THEN 1 ELSE 0 END)
        * 100.0 / COUNT(*), 2
    ) AS sla_breach_rate_pct,
    ROUND(AVG(tat_days), 2) AS average_tat_days
FROM loan_applications
WHERE tat_days IS NOT NULL;

SELECT
    customer_segment,
    COUNT(*) AS applications_with_tat,
    SUM(CASE WHEN tat_days > 3 THEN 1 ELSE 0 END) AS sla_breaches,
    ROUND(
        SUM(CASE WHEN tat_days > 3 THEN 1 ELSE 0 END)
        * 100.0 / COUNT(*), 2
    ) AS sla_breach_rate_pct,
    ROUND(AVG(tat_days), 2) AS average_tat_days
FROM loan_applications
WHERE tat_days IS NOT NULL
GROUP BY customer_segment
ORDER BY sla_breach_rate_pct DESC;


SELECT
    channel,
    COUNT(*) AS applications_with_tat,
    SUM(CASE WHEN tat_days > 3 THEN 1 ELSE 0 END) AS sla_breaches,
    ROUND(
        SUM(CASE WHEN tat_days > 3 THEN 1 ELSE 0 END)
        * 100.0 / COUNT(*), 2
    ) AS sla_breach_rate_pct,
    ROUND(AVG(tat_days), 2) AS average_tat_days
FROM loan_applications
WHERE tat_days IS NOT NULL
GROUP BY channel
ORDER BY sla_breach_rate_pct DESC;
